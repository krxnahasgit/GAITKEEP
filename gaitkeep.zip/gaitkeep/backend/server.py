from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import cv2
import mediapipe as mp
import numpy as np
import tempfile
import os
from werkzeug.utils import secure_filename
import hashlib
import cmath
import json
from scipy import integrate, signal
from scipy.interpolate import interp1d
import time

app = Flask(__name__, static_folder='frontend', static_url_path='')
CORS(app)

# MediaPipe setup
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils
pose = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.7, min_tracking_confidence=0.7)

# Key joints for 12-point analysis (MediaPipe landmark indices)
KEY_JOINTS = {
    'left_shoulder': 11, 'right_shoulder': 12,
    'left_hip': 23, 'right_hip': 24,
    'left_knee': 25, 'right_knee': 26,
    'left_ankle': 27, 'right_ankle': 28,
    'left_heel': 29, 'right_heel': 30,
    'left_toe': 31, 'right_toe': 32
}

# Global storage for actual joint trajectories
gait_database = {}

class GaitAnalyzer:
    def __init__(self):
        self.joint_positions = []
        self.timestamps = []
        self.raw_trajectories = []  # Store actual joint movements
        
    def extract_keypoints(self, video_path, progress_callback=None):
        """Extract 12 key joints from video using MediaPipe and store RAW trajectories"""
        cap = cv2.VideoCapture(video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        
        frame_data = []
        raw_trajectory_data = []
        frame_count = 0
        
        if progress_callback:
            progress_callback("Extracting pose data from video...", 0)
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            # Convert BGR to RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = pose.process(rgb_frame)
            
            if results.pose_landmarks:
                # Extract 12 key joint positions
                joints = {}
                raw_joints = {}  # Store raw positions for true reconstruction
                
                for joint_name, landmark_idx in KEY_JOINTS.items():
                    landmark = results.pose_landmarks.landmark[landmark_idx]
                    # Normalize to video dimensions for consistent playback
                    joints[joint_name] = [landmark.x, landmark.y, landmark.z]
                    raw_joints[joint_name] = {
                        'x': landmark.x * frame.shape[1],  # Pixel coordinates
                        'y': landmark.y * frame.shape[0],
                        'z': landmark.z,
                        'visibility': landmark.visibility
                    }
                
                timestamp = frame_count / fps
                frame_data.append({
                    'timestamp': timestamp,
                    'joints': joints
                })
                
                # Store raw trajectory data for true reconstruction
                raw_trajectory_data.append({
                    'frame': frame_count,
                    'timestamp': timestamp,
                    'joints': raw_joints,
                    'frame_dims': {'width': frame.shape[1], 'height': frame.shape[0]}
                })
            
            frame_count += 1
            if progress_callback and frame_count % 10 == 0:
                progress = int((frame_count / total_frames) * 30)  # 30% for extraction
                progress_callback("Extracting pose data...", progress)
        
        cap.release()
        self.joint_positions = frame_data
        self.raw_trajectories = raw_trajectory_data  # Store the actual movements
        return frame_data
    
    def calculate_velocities(self, progress_callback=None):
        """Calculate joint velocities (ṙ)"""
        if progress_callback:
            progress_callback("Calculating joint velocities...", 35)
            
        velocities = []
        
        for i in range(1, len(self.joint_positions)):
            dt = self.joint_positions[i]['timestamp'] - self.joint_positions[i-1]['timestamp']
            if dt > 0:
                frame_velocities = {}
                for joint_name in KEY_JOINTS.keys():
                    curr_pos = np.array(self.joint_positions[i]['joints'][joint_name])
                    prev_pos = np.array(self.joint_positions[i-1]['joints'][joint_name])
                    velocity = (curr_pos - prev_pos) / dt
                    frame_velocities[joint_name] = velocity
                
                velocities.append({
                    'timestamp': self.joint_positions[i]['timestamp'],
                    'velocities': frame_velocities
                })
        
        return velocities
    
    def calculate_phase_function(self, velocities, progress_callback=None):
        """Calculate phase function φ(t) from knee flexion angle"""
        if progress_callback:
            progress_callback("Computing gait phase alignment...", 50)
            
        phases = []
        
        for frame in self.joint_positions:
            # Calculate knee flexion angle using hip-knee-ankle points
            left_hip = np.array(frame['joints']['left_hip'][:2])  # Use only x,y
            left_knee = np.array(frame['joints']['left_knee'][:2])
            left_ankle = np.array(frame['joints']['left_ankle'][:2])
            
            # Vectors from knee to hip and knee to ankle
            v1 = left_hip - left_knee
            v2 = left_ankle - left_knee
            
            # Calculate angle
            cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-8)
            cos_angle = np.clip(cos_angle, -1.0, 1.0)
            angle = np.arccos(cos_angle)
            
            phases.append({
                'timestamp': frame['timestamp'],
                'phase': angle
            })
        
        return phases
    
    def compute_pca_weights(self, velocities):
        """Dynamically compute optimal weighting vector using PCA"""
        # Aggregate all velocity vectors
        all_velocities = []
        for frame in velocities:
            for joint_name, vel in frame['velocities'].items():
                if 'hip' in joint_name or 'knee' in joint_name:  # Focus on key gait joints
                    all_velocities.append(vel[:3])  # x, y, z components
        
        if len(all_velocities) < 3:
            return np.array([0.8, 1.2, 0.6])  # Fallback weights
        
        all_velocities = np.array(all_velocities)
        
        # Simple PCA - find principal component
        cov_matrix = np.cov(all_velocities.T)
        eigenvals, eigenvecs = np.linalg.eigh(cov_matrix)
        
        # Use first principal component as weights, normalized
        weights = eigenvecs[:, -1]  # Largest eigenvalue's eigenvector
        weights = np.abs(weights) / np.linalg.norm(weights)
        
        return weights
    
    def compute_gait_signature(self, height_m, progress_callback=None):
        """Compute the complete gait signature using the biomechanical formula"""
        if progress_callback:
            progress_callback("Computing biomechanical signature...", 70)
        
        # Extract velocities and phases
        velocities = self.calculate_velocities()
        phases = self.calculate_phase_function(velocities)
        
        if len(velocities) == 0 or len(phases) == 0:
            return None, None, None
        
        # Compute dynamic weighting vector
        w = self.compute_pca_weights(velocities)
        
        # Align timestamps and interpolate
        vel_times = [v['timestamp'] for v in velocities]
        phase_times = [p['timestamp'] for p in phases]
        
        # Find common time range
        start_time = max(min(vel_times), min(phase_times))
        end_time = min(max(vel_times), max(phase_times))
        
        if end_time <= start_time:
            return None, None, None
        
        # Create interpolated functions
        common_times = np.linspace(start_time, end_time, min(100, len(velocities)))
        
        # Average hip velocities for center of mass approximation
        hip_vels = []
        for frame in velocities:
            left_hip_vel = frame['velocities']['left_hip']
            right_hip_vel = frame['velocities']['right_hip']
            avg_hip_vel = (left_hip_vel + right_hip_vel) / 2
            hip_vels.append(avg_hip_vel)
        
        hip_vels = np.array(hip_vels)
        
        # Interpolate velocities and phases to common timeline
        if len(hip_vels) < 2:
            return None, None, None
            
        interp_vx = interp1d(vel_times, hip_vels[:, 0], kind='linear', fill_value='extrapolate')
        interp_vy = interp1d(vel_times, hip_vels[:, 1], kind='linear', fill_value='extrapolate')
        interp_vz = interp1d(vel_times, hip_vels[:, 2], kind='linear', fill_value='extrapolate')
        
        phase_vals = [p['phase'] for p in phases]
        interp_phase = interp1d(phase_times, phase_vals, kind='linear', fill_value='extrapolate')
        
        # Compute the integral: s = ∫(w·ṙ) e^{-iφ(t)} dt / H
        integrand = []
        for t in common_times:
            r_dot = np.array([interp_vx(t), interp_vy(t), interp_vz(t)])
            w_dot_r = np.dot(w, r_dot)
            phi_t = interp_phase(t)
            complex_term = w_dot_r * cmath.exp(-1j * phi_t)
            integrand.append(complex_term)
        
        # Numerical integration using trapezoidal rule
        dt = (end_time - start_time) / (len(common_times) - 1)
        integral = np.trapz(integrand, dx=dt)
        
        # Normalize by height
        gait_signature = integral / height_m
        
        if progress_callback:
            progress_callback("Generating unique hash...", 90)
        
        # Generate hash from signature
        sig_str = f"{gait_signature.real:.6f}_{gait_signature.imag:.6f}"
        gait_hash = hashlib.sha256(sig_str.encode()).hexdigest()[:16]
        
        # Return signature, hash, AND the raw trajectory data
        return gait_signature, gait_hash, self.raw_trajectories

@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('frontend', path)

@app.route('/analyze_gait', methods=['POST'])
def analyze_gait():
    try:
        if 'video' not in request.files:
            return jsonify({'error': 'No video file provided'}), 400
        
        video_file = request.files['video']
        height = float(request.form.get('height', 1.7))  # Default 1.7m
        
        if video_file.filename == '':
            return jsonify({'error': 'No video selected'}), 400
        
        # Check file size (5MB limit)
        if len(video_file.read()) > 5 * 1024 * 1024:
            return jsonify({'error': 'Video file too large (max 5MB)'}), 400
        video_file.seek(0)  # Reset file pointer
        
        # Save temporary file
        temp_dir = tempfile.mkdtemp()
        filename = secure_filename(video_file.filename)
        temp_path = os.path.join(temp_dir, filename)
        video_file.save(temp_path)
        
        def progress_update(message, percent):
            # In a real implementation, you'd use WebSockets or SSE
            print(f"Progress: {message} ({percent}%)")
        
        # Analyze gait
        analyzer = GaitAnalyzer()
        joint_data = analyzer.extract_keypoints(temp_path, progress_update)
        
        if not joint_data:
            return jsonify({'error': 'No pose detected in video'}), 400
        
        gait_signature, gait_hash, raw_trajectories = analyzer.compute_gait_signature(height, progress_update)
        
        # Cleanup
        os.remove(temp_path)
        os.rmdir(temp_dir)
        
        if gait_signature is None:
            return jsonify({'error': 'Failed to compute gait signature'}), 400
        
        # Store the actual trajectory data globally for reconstruction
        gait_database[gait_hash] = {
            'trajectories': raw_trajectories,
            'signature': gait_signature,
            'height': height,
            'timestamp': time.time()
        }
        
        return jsonify({
            'success': True,
            'scalar': {
                'real': float(gait_signature.real),
                'imag': float(gait_signature.imag)
            },
            'hash': gait_hash,
            'frames_processed': len(joint_data),
            'has_trajectories': True  # Indicate we have real data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/reconstruct_gait', methods=['POST'])
def reconstruct_gait():
    try:
        data = request.json
        scalar_real = float(data.get('scalar_real', 0))
        scalar_imag = float(data.get('scalar_imag', 0))
        gait_hash = data.get('hash', '')
        
        # Check if we have the actual trajectory data for this hash
        if gait_hash in gait_database:
            # Use the REAL trajectory data from the original video
            stored_data = gait_database[gait_hash]
            trajectories = stored_data['trajectories']
            
            # Convert raw trajectories to normalized format for playback
            normalized_trajectories = []
            
            if trajectories:
                # Get reference frame dimensions
                ref_width = trajectories[0]['frame_dims']['width']
                ref_height = trajectories[0]['frame_dims']['height']
                
                for frame_data in trajectories:
                    normalized_frame = {
                        'timestamp': frame_data['timestamp'],
                        'joints': {}
                    }
                    
                    # Normalize joint positions to 0-1 range for consistent playback
                    for joint_name, joint_data in frame_data['joints'].items():
                        normalized_frame['joints'][joint_name] = {
                            'x': joint_data['x'] / ref_width,
                            'y': joint_data['y'] / ref_height,
                            'z': joint_data.get('z', 0),
                            'visibility': joint_data.get('visibility', 1.0)
                        }
                    
                    normalized_trajectories.append(normalized_frame)
            
            # Calculate actual gait parameters from the real data
            magnitude = abs(complex(scalar_real, scalar_imag))
            phase = cmath.phase(complex(scalar_real, scalar_imag))
            
            # Extract real step characteristics from trajectory data
            step_length = calculate_actual_step_length(trajectories) if trajectories else magnitude * 0.5
            cadence = calculate_actual_cadence(trajectories) if trajectories else 120
            
            return jsonify({
                'success': True,
                'trajectories': normalized_trajectories,  # Real joint movements from video
                'parameters': {
                    'step_length': step_length,
                    'cadence': cadence,
                    'magnitude': magnitude,
                    'phase': phase,
                    'is_real_data': True  # Flag to indicate this is real trajectory data
                },
                'frame_count': len(normalized_trajectories)
            })
        
        else:
            # Fallback: generate synthetic pattern if no real data available
            gait_signature = complex(scalar_real, scalar_imag)
            magnitude = abs(gait_signature)
            phase = cmath.phase(gait_signature)
            
            # Generate basic synthetic walking cycle
            step_length = min(max(magnitude * 0.5, 0.3), 0.8)
            cadence = min(max(120 + phase * 10, 90), 150)
            
            # Create simple synthetic trajectory
            cycle_frames = []
            for i in range(60):
                t = i / 60.0
                cycle_phase = t * 2 * np.pi
                
                frame = {
                    'timestamp': t,
                    'joints': {
                        'left_hip': {'x': 0.45 + np.sin(cycle_phase) * 0.05, 'y': 0.4, 'z': 0, 'visibility': 1.0},
                        'right_hip': {'x': 0.55 + np.sin(cycle_phase + np.pi) * 0.05, 'y': 0.4, 'z': 0, 'visibility': 1.0},
                        'left_knee': {'x': 0.45 + np.sin(cycle_phase) * 0.08, 'y': 0.6, 'z': 0, 'visibility': 1.0},
                        'right_knee': {'x': 0.55 + np.sin(cycle_phase + np.pi) * 0.08, 'y': 0.6, 'z': 0, 'visibility': 1.0},
                        'left_ankle': {'x': 0.45 + np.sin(cycle_phase) * 0.1, 'y': 0.9, 'z': 0, 'visibility': 1.0},
                        'right_ankle': {'x': 0.55 + np.sin(cycle_phase + np.pi) * 0.1, 'y': 0.9, 'z': 0, 'visibility': 1.0}
                    }
                }
                cycle_frames.append(frame)
            
            return jsonify({
                'success': True,
                'trajectories': cycle_frames,
                'parameters': {
                    'step_length': step_length,
                    'cadence': cadence,
                    'magnitude': magnitude,
                    'phase': phase,
                    'is_real_data': False
                },
                'frame_count': len(cycle_frames)
            })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def calculate_actual_step_length(trajectories):
    """Calculate actual step length from trajectory data"""
    if not trajectories or len(trajectories) < 10:
        return 0.5
    
    left_ankle_positions = []
    right_ankle_positions = []
    
    for frame in trajectories:
        if 'left_ankle' in frame['joints']:
            left_ankle_positions.append(frame['joints']['left_ankle']['x'])
        if 'right_ankle' in frame['joints']:
            right_ankle_positions.append(frame['joints']['right_ankle']['x'])
    
    if len(left_ankle_positions) > 0 and len(right_ankle_positions) > 0:
        left_range = max(left_ankle_positions) - min(left_ankle_positions)
        right_range = max(right_ankle_positions) - min(right_ankle_positions)
        avg_range = (left_range + right_range) / 2
        return avg_range * 2  # Convert to meters approximately
    
    return 0.5

def calculate_actual_cadence(trajectories):
    """Calculate actual cadence from trajectory data"""
    if not trajectories or len(trajectories) < 20:
        return 120
    
    # Simple heel strike detection based on ankle position changes
    left_ankle_y = [frame['joints']['left_ankle']['y'] for frame in trajectories if 'left_ankle' in frame['joints']]
    
    if len(left_ankle_y) < 10:
        return 120
    
    # Find peaks (approximate heel strikes)
    peaks = []
    for i in range(1, len(left_ankle_y) - 1):
        if left_ankle_y[i] > left_ankle_y[i-1] and left_ankle_y[i] > left_ankle_y[i+1]:
            peaks.append(i)
    
    if len(peaks) > 1:
        total_time = trajectories[-1]['timestamp'] - trajectories[0]['timestamp']
        steps_per_second = len(peaks) / total_time
        cadence = steps_per_second * 60 * 2  # Convert to steps per minute
        return min(max(cadence, 60), 180)  # Reasonable cadence range
    
    return 120

if __name__ == '__main__':
    print("🚀 GaitKeep Server Starting...")
    print("📍 Server running at: http://localhost:5000")
    print("🔄 To stop server: Press Ctrl+C")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)